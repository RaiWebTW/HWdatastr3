#include <iostream>
#include <vector>
using namespace std;

void dfsUtil(int node, vector<vector<int>> &adj, vector<int> &visited, vector<int> &dfsResult) {
    visited[node] = 1;
    dfsResult.push_back(node);

    for (int neighbor : adj[node]) {
        if (!visited[neighbor]) {
            dfsUtil(neighbor, adj, visited, dfsResult);
        }
    }
}

vector<int> dfsTraversal(vector<vector<int>> &adj, int start) {
    int V = adj.size();
    vector<int> visited(V, 0);
    vector<int> dfsResult;

    dfsUtil(start, adj, visited, dfsResult);

    return dfsResult;
}

int main() {
    int V, E;
    cout << "Enter the number of vertices (V): ";
    cin >> V;
    cout << "Enter the number of edges (E): ";
    cin >> E;

    vector<vector<int>> adj(V);
    cout << "Enter the edges (u v) for each edge:\n";
    for (int i = 0; i < E; i++) {
        int u, v;
        cin >> u >> v;
        adj[u].push_back(v);
        adj[v].push_back(u);
    }

    vector<int> dfsResult = dfsTraversal(adj, 0);

    cout << "DFS Traversal starting from node 0:\n";
    for (int node : dfsResult) cout << node << " ";
    cout << endl;

    return 0;
}
