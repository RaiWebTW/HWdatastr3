#include <iostream>
#include <vector>
#include <queue>
using namespace std;
vector<int> bfsTraversal(int V, vector<vector<int>>& adj) {
    vector<int> bfs;
    vector<bool> visited(V, false);
    queue<int> q;
    q.push(0);
    visited[0] = true;
    while (!q.empty()) {
        int node = q.front();
        q.pop();
        bfs.push_back(node);
        for (int neighbor : adj[node]) {
            if (!visited[neighbor]) {
                q.push(neighbor);
                visited[neighbor] = true;
            }
        }
    }
    return bfs;
}


